import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AllComponent } from './all/all/all.component';
import { BangaloreComponent } from './bangalore/bangalore/bangalore.component';
import { HyderbadComponent } from './hyderbad/hyderbad/hyderbad.component';

@NgModule({
  declarations: [
    AppComponent,
    AllComponent,
    BangaloreComponent,
    HyderbadComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
