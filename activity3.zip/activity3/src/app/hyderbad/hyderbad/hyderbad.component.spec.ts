import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HyderbadComponent } from './hyderbad.component';

describe('HyderbadComponent', () => {
  let component: HyderbadComponent;
  let fixture: ComponentFixture<HyderbadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HyderbadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HyderbadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
