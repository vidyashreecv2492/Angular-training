import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bangalore',
  templateUrl: './bangalore.component.html',
  styleUrls: ['./bangalore.component.css']
})
export class BangaloreComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  users = [
    {'Id':1,'Name':'Abhishek','Location':'Bangalore'},
    {'Id':2,'Name':'Bhavya','Location':'Bangalore'},
    {'Id':3,'Name':'Deepa','Location':'Hyderbad'},
    {'Id':4,'Name':'Kiran','Location':'Bangalore'},
    {'Id':5,'Name':'Neha','Location':'Hyderbad'},

  ]

}
